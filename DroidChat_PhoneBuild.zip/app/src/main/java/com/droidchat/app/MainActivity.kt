package com.droidchat.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class Droid(
    val id: String,
    val name: String,
    val model: String,
    val description: String,
    val colour: androidx.compose.ui.graphics.Color
)

data class ChatMessage(val fromUser: Boolean, val text: String)

private val droids = listOf(
    Droid("luma", "Luma", "LX-01", "Friendly household assistant. Curious, literal, and extremely eager to help.", MaterialTheme.colorScheme.primary),
    Droid("atlas", "Atlas", "AT-7", "A practical general-purpose Droid with a dry sense of humour.", MaterialTheme.colorScheme.secondary),
    Droid("nova", "Nova", "NV-3", "Experimental social Droid. Energetic, observant, and unpredictable.", MaterialTheme.colorScheme.tertiary)
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { DroidChatApp() }
    }
}

@Composable
fun DroidChatApp() {
    MaterialTheme {
        var selected by remember { mutableStateOf<Droid?>(null) }
        if (selected == null) DroidPicker(onSelect = { selected = it })
        else ChatScreen(droid = selected!!, onBack = { selected = null })
    }
}

@Composable
fun DroidPicker(onSelect: (Droid) -> Unit) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("DroidChat", fontWeight = FontWeight.Bold)
                        Text("Choose your Droid", fontSize = 12.sp)
                    }
                },
                actions = { IconButton(onClick = {}) { Icon(Icons.Default.Settings, "Settings") } }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.padding(padding).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Spacer(Modifier.height(8.dp))
                Text("Available models", fontSize = 24.sp, fontWeight = FontWeight.Bold)
                Text("Each Droid has its own personality and conversation history.")
            }
            items(droids) { droid ->
                DroidCard(droid, onClick = { onSelect(droid) })
            }
            item {
                OutlinedButton(
                    onClick = {},
                    modifier = Modifier.fillMaxWidth().height(54.dp)
                ) { Text("+ Create your own Droid") }
                Spacer(Modifier.height(24.dp))
            }
        }
    }
}

@Composable
fun DroidCard(droid: Droid, onClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        shape = RoundedCornerShape(22.dp)
    ) {
        Row(
            modifier = Modifier.padding(18.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier.size(58.dp).clip(CircleShape).background(droid.colour),
                contentAlignment = Alignment.Center
            ) { Text("🤖", fontSize = 27.sp) }

            Spacer(Modifier.width(15.dp))
            Column(Modifier.weight(1f)) {
                Text(droid.name, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                Text(droid.model, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.height(5.dp))
                Text(droid.description, fontSize = 14.sp)
            }
        }
    }
}

@Composable
fun ChatScreen(droid: Droid, onBack: () -> Unit) {
    var input by remember { mutableStateOf("") }
    val messages = remember {
        mutableStateListOf(
            ChatMessage(false, "Hello. I am ${droid.name}, model ${droid.model}. How may I assist you?")
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back") }
                },
                title = {
                    Column {
                        Text(droid.name, fontWeight = FontWeight.Bold)
                        Text(droid.model, fontSize = 12.sp)
                    }
                }
            )
        },
        bottomBar = {
            Row(
                Modifier.fillMaxWidth().padding(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("Message ${droid.name}...") },
                    shape = RoundedCornerShape(24.dp),
                    maxLines = 4
                )
                Spacer(Modifier.width(8.dp))
                FloatingActionButton(
                    onClick = {
                        val trimmed = input.trim()
                        if (trimmed.isNotEmpty()) {
                            messages.add(ChatMessage(true, trimmed))
                            messages.add(ChatMessage(false, demoReply(droid, trimmed)))
                            input = ""
                        }
                    }
                ) { Icon(Icons.Default.Send, "Send") }
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.padding(padding).fillMaxSize().padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(messages) { message ->
                MessageBubble(message)
            }
        }
    }
}

@Composable
fun MessageBubble(message: ChatMessage) {
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = if (message.fromUser) Arrangement.End else Arrangement.Start
    ) {
        Surface(
            color = if (message.fromUser) MaterialTheme.colorScheme.primaryContainer
                    else MaterialTheme.colorScheme.surfaceVariant,
            shape = RoundedCornerShape(18.dp),
            modifier = Modifier.widthIn(max = 310.dp)
        ) {
            Text(message.text, Modifier.padding(13.dp))
        }
    }
}

private fun demoReply(droid: Droid, input: String): String {
    return when (droid.id) {
        "luma" -> "Processing your statement: "$input". I believe a helpful response would be appropriate. I am still learning what humans mean by that."
        "atlas" -> "Noted. I have filed that information in the extremely important folder labelled 'Things You Just Said'."
        else -> "Interesting. My ${droid.model} conversational systems have detected approximately 47 possible responses. I selected this one."
    }
}
