# DroidChat

An original Android AI-chat app prototype inspired by the idea of selectable robot models.

## Current prototype
- Droid selection screen
- Individual Droid profiles
- Chat interface
- Per-Droid demo personalities
- Local in-memory conversation state

## Planned 1.0
- Secure backend AI integration
- Persistent accounts and chat history
- Character creator
- Text-to-speech and voice conversations
- Safety/reporting tools
- Privacy/data controls
- Play Store release build

The included characters are original placeholders, not characters or voices from any existing TV programme.
